import type { Hunter, InsertHunter, Boundary, InsertBoundary } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getHunter(id: string): Promise<Hunter | undefined>;
  getAllHunters(): Promise<Hunter[]>;
  createHunter(hunter: InsertHunter): Promise<Hunter>;
  updateHunter(id: string, hunter: Partial<InsertHunter>): Promise<Hunter | undefined>;
  deleteHunter(id: string): Promise<boolean>;
  
  getBoundary(id: string): Promise<Boundary | undefined>;
  getAllBoundaries(): Promise<Boundary[]>;
  createBoundary(boundary: InsertBoundary): Promise<Boundary>;
  deleteBoundary(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private hunters: Map<string, Hunter>;
  private boundaries: Map<string, Boundary>;

  constructor() {
    this.hunters = new Map();
    this.boundaries = new Map();
  }

  async getHunter(id: string): Promise<Hunter | undefined> {
    return this.hunters.get(id);
  }

  async getAllHunters(): Promise<Hunter[]> {
    return Array.from(this.hunters.values());
  }

  async createHunter(insertHunter: InsertHunter): Promise<Hunter> {
    const id = randomUUID();
    const hunter: Hunter = {
      ...insertHunter,
      id,
      lastUpdate: new Date(),
    };
    this.hunters.set(id, hunter);
    return hunter;
  }

  async updateHunter(
    id: string,
    updates: Partial<InsertHunter>
  ): Promise<Hunter | undefined> {
    const hunter = this.hunters.get(id);
    if (!hunter) return undefined;

    const updated: Hunter = {
      ...hunter,
      ...updates,
      lastUpdate: new Date(),
    };
    this.hunters.set(id, updated);
    return updated;
  }

  async deleteHunter(id: string): Promise<boolean> {
    return this.hunters.delete(id);
  }

  async getBoundary(id: string): Promise<Boundary | undefined> {
    return this.boundaries.get(id);
  }

  async getAllBoundaries(): Promise<Boundary[]> {
    return Array.from(this.boundaries.values());
  }

  async createBoundary(insertBoundary: InsertBoundary): Promise<Boundary> {
    const id = randomUUID();
    const boundary: Boundary = {
      ...insertBoundary,
      id,
      createdAt: new Date(),
    };
    this.boundaries.set(id, boundary);
    return boundary;
  }

  async deleteBoundary(id: string): Promise<boolean> {
    return this.boundaries.delete(id);
  }
}

export const storage = new MemStorage();
