import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertHunterSchema, insertBoundarySchema } from "@shared/schema";
import type { WSMessage } from "@shared/schema";

interface WSClient extends WebSocket {
  hunterId?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  const clients = new Set<WSClient>();

  function broadcast(message: WSMessage, excludeClient?: WSClient) {
    const data = JSON.stringify(message);
    clients.forEach((client) => {
      if (client !== excludeClient && client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }

  wss.on("connection", (ws: WSClient) => {
    console.log("New WebSocket connection");
    clients.add(ws);

    storage.getAllHunters().then((hunters) => {
      hunters.forEach((hunter) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(
            JSON.stringify({
              type: "position_update",
              data: {
                id: hunter.id,
                name: hunter.name,
                lat: parseFloat(hunter.latitude),
                lng: parseFloat(hunter.longitude),
                heading: hunter.heading ? parseFloat(hunter.heading) : undefined,
                lastUpdate: hunter.lastUpdate.toISOString(),
              },
            })
          );
        }
      });
    });

    ws.on("message", async (data: Buffer) => {
      try {
        const message: WSMessage = JSON.parse(data.toString());

        if (message.type === "hunter_joined") {
          const hunter = await storage.createHunter({
            name: message.data.name,
            latitude: message.data.lat.toString(),
            longitude: message.data.lng.toString(),
            heading: message.data.heading?.toString(),
          });

          ws.hunterId = hunter.id;

          const responseData = {
            id: hunter.id,
            name: hunter.name,
            lat: parseFloat(hunter.latitude),
            lng: parseFloat(hunter.longitude),
            heading: hunter.heading ? parseFloat(hunter.heading) : undefined,
            lastUpdate: hunter.lastUpdate.toISOString(),
          };

          if (ws.readyState === WebSocket.OPEN) {
            ws.send(
              JSON.stringify({
                type: "hunter_joined",
                data: responseData,
              })
            );
          }

          broadcast(
            {
              type: "position_update",
              data: responseData,
            },
            ws
          );
        } else if (message.type === "position_update") {
          const hunterId = message.data.id || ws.hunterId;
          if (hunterId) {
            const updated = await storage.updateHunter(hunterId, {
              latitude: message.data.lat.toString(),
              longitude: message.data.lng.toString(),
              heading: message.data.heading?.toString(),
            });

            if (updated) {
              broadcast(
                {
                  type: "position_update",
                  data: {
                    id: updated.id,
                    name: updated.name,
                    lat: parseFloat(updated.latitude),
                    lng: parseFloat(updated.longitude),
                    heading: updated.heading ? parseFloat(updated.heading) : undefined,
                    lastUpdate: updated.lastUpdate.toISOString(),
                  },
                },
                ws
              );
            }
          }
        } else if (message.type === "boundary_update") {
          broadcast(message, ws);
        }
      } catch (error) {
        console.error("Error handling WebSocket message:", error);
      }
    });

    ws.on("close", async () => {
      console.log("WebSocket connection closed");
      clients.delete(ws);

      if (ws.hunterId) {
        await storage.deleteHunter(ws.hunterId);
        broadcast({
          type: "hunter_left",
          data: { id: ws.hunterId },
        });
      }
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
    });
  });

  app.get("/api/hunters", async (req, res) => {
    try {
      const hunters = await storage.getAllHunters();
      const formattedHunters = hunters.map((h) => ({
        id: h.id,
        name: h.name,
        lat: parseFloat(h.latitude),
        lng: parseFloat(h.longitude),
        heading: h.heading ? parseFloat(h.heading) : undefined,
        lastUpdate: h.lastUpdate.toISOString(),
      }));
      res.json(formattedHunters);
    } catch (error) {
      console.error("Error fetching hunters:", error);
      res.status(500).json({ error: "Failed to fetch hunters" });
    }
  });

  app.get("/api/boundaries", async (req, res) => {
    try {
      const boundaries = await storage.getAllBoundaries();
      const formattedBoundaries = boundaries.map((b) => ({
        id: b.id,
        name: b.name,
        coordinates: JSON.parse(b.coordinates),
        createdAt: b.createdAt.toISOString(),
      }));
      res.json(formattedBoundaries);
    } catch (error) {
      console.error("Error fetching boundaries:", error);
      res.status(500).json({ error: "Failed to fetch boundaries" });
    }
  });

  app.post("/api/boundaries", async (req, res) => {
    try {
      const parsed = insertBoundarySchema.parse({
        name: req.body.name,
        coordinates: JSON.stringify(req.body.coordinates),
      });

      const boundary = await storage.createBoundary(parsed);

      res.status(201).json({
        id: boundary.id,
        name: boundary.name,
        coordinates: JSON.parse(boundary.coordinates),
        createdAt: boundary.createdAt.toISOString(),
      });
    } catch (error) {
      console.error("Error creating boundary:", error);
      res.status(400).json({ error: "Failed to create boundary" });
    }
  });

  app.delete("/api/boundaries/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteBoundary(req.params.id);
      if (deleted) {
        res.status(204).send();
      } else {
        res.status(404).json({ error: "Boundary not found" });
      }
    } catch (error) {
      console.error("Error deleting boundary:", error);
      res.status(500).json({ error: "Failed to delete boundary" });
    }
  });

  app.post("/api/boundaries/import", async (req, res) => {
    try {
      const { source, lat, lng, radiusMiles = 50 } = req.body;
      
      if (!source || !lat || !lng) {
        return res.status(400).json({ error: "Missing required fields: source, lat, lng" });
      }

      const radiusMeters = radiusMiles * 1609.34;
      const degreeOffset = radiusMiles / 69;
      
      const bbox = {
        xmin: lng - degreeOffset,
        ymin: lat - degreeOffset,
        xmax: lng + degreeOffset,
        ymax: lat + degreeOffset
      };

      let url: string;
      let layerName: string;

      if (source === "blm") {
        url = "https://gis.blm.gov/arcgis/rest/services/lands/BLM_Natl_SMA_LM_POL/FeatureServer/0/query";
        layerName = "BLM Public Lands";
      } else if (source === "usfs") {
        url = "https://apps.fs.usda.gov/arcx/rest/services/EDW/EDW_ProclaimedForestsAndGrasslands_01/MapServer/0/query";
        layerName = "National Forests";
      } else {
        return res.status(400).json({ error: "Invalid source. Use 'blm' or 'usfs'" });
      }

      const params = new URLSearchParams({
        geometry: JSON.stringify(bbox),
        geometryType: "esriGeometryEnvelope",
        spatialRel: "esriSpatialRelIntersects",
        outFields: "*",
        returnGeometry: "true",
        f: "geojson"
      });

      const response = await fetch(`${url}?${params}`);
      if (!response.ok) {
        throw new Error(`GIS API request failed: ${response.statusText}`);
      }

      const geoJsonData = await response.json();
      
      if (!geoJsonData.features || geoJsonData.features.length === 0) {
        return res.json({ imported: 0, message: "No boundaries found in this area" });
      }

      const importedBoundaries = [];
      for (const feature of geoJsonData.features.slice(0, 10)) {
        if (feature.geometry.type === "Polygon") {
          const coords = feature.geometry.coordinates[0].map((coord: number[]) => ({
            lat: coord[1],
            lng: coord[0]
          }));

          const name = feature.properties?.ADMU_NAME || 
                       feature.properties?.FORESTNAME || 
                       feature.properties?.NAME || 
                       `${layerName} Area`;

          const boundary = await storage.createBoundary({
            name,
            coordinates: JSON.stringify(coords)
          });

          importedBoundaries.push({
            id: boundary.id,
            name: boundary.name,
            coordinates: JSON.parse(boundary.coordinates),
            createdAt: boundary.createdAt.toISOString()
          });
        } else if (feature.geometry.type === "MultiPolygon") {
          for (const polygon of feature.geometry.coordinates.slice(0, 3)) {
            const coords = polygon[0].map((coord: number[]) => ({
              lat: coord[1],
              lng: coord[0]
            }));

            const name = feature.properties?.ADMU_NAME || 
                         feature.properties?.FORESTNAME || 
                         feature.properties?.NAME || 
                         `${layerName} Area`;

            const boundary = await storage.createBoundary({
              name,
              coordinates: JSON.stringify(coords)
            });

            importedBoundaries.push({
              id: boundary.id,
              name: boundary.name,
              coordinates: JSON.parse(boundary.coordinates),
              createdAt: boundary.createdAt.toISOString()
            });
          }
        }
      }

      res.json({
        imported: importedBoundaries.length,
        boundaries: importedBoundaries
      });
    } catch (error) {
      console.error("Error importing GIS boundaries:", error);
      res.status(500).json({ error: "Failed to import boundaries from GIS source" });
    }
  });

  return httpServer;
}
