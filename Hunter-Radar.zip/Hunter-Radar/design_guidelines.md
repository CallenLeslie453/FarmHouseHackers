# Hunter Radar Tracking Application - Design Guidelines

## Design Approach

**Selected Framework**: Material Design 3 with Military/Tactical Adaptation
**Rationale**: Utility-focused safety tool requiring rugged aesthetics optimized for outdoor readability. The military/hunting theme provides familiar visual language for the target audience while maintaining functional clarity.

**Core Principles**:
- Tactical readability - high contrast orange-on-camo for outdoor visibility
- Military precision - crisp edges, monospace data, no-nonsense layouts
- Map-centric interface - radar/compass as primary navigation element
- Field-ready durability - all controls accessible with gloves

---

## Color System

**Background Palette (Camouflage)**:
- Primary backgrounds: Woodland camo pattern (greens #4A5D3F, #3A4D2F, browns #6B5444, tans #9B8B7B)
- Panel overlays: Semi-transparent camo with 85% opacity for readability
- Subtle noise texture overlay on all backgrounds for tactile feel

**High-Visibility Safety Orange (#FF6600)**:
- All text content (headings, body, labels)
- All interactive elements (buttons, links, icons)
- Data readouts (distance, bearing, time)
- Alert indicators and warnings
- Active states and focus indicators

**Supporting Colors**:
- White (#FFFFFF): Used only for extreme contrast needs (alert backgrounds)
- Black (#000000): Deep shadows, panel borders at 20% opacity
- Translucent overlays: Camo patterns at varying opacity levels

---

## Layout System

**Spacing Scale**: Tailwind units **2, 4, 6, 8, 12**
- Component padding: p-6 (panels), p-4 (cards)
- Section gaps: gap-4 between controls, gap-6 for major sections
- Panel margins: m-4 from viewport edges
- Icon-text spacing: gap-2

**Viewport Strategy**:
- Full-screen radar/map interface (`h-screen`)
- Floating tactical HUD panels overlay the map
- No vertical scrolling on main view
- All information accessible via layered panels

**Grid Structure**:
- Mobile: Full-screen radar with slide-up tactical drawer
- Desktop: Radar center-stage with floating corner panels (military HUD style)

---

## Typography

**Font Families** (Google Fonts CDN):
- Primary: **Rajdhani** (Bold, military-style sans-serif for headings/UI)
- Data Display: **Roboto Mono** (Monospace for precise readouts)
- Body: **Inter** (Clean, readable for secondary content)

**Type Scale**:
- **H1** (App Title): 28px, Rajdhani-700, uppercase, tracking-widest, safety orange
- **H2** (Panel Headers): 20px, Rajdhani-600, uppercase, tracking-wide
- **H3** (Section Labels): 16px, Rajdhani-500, uppercase
- **Data Readouts**: 24px, Roboto Mono-700 (distance/bearing displays)
- **Body Text**: 14px, Inter-400, line-height-relaxed
- **Secondary Info**: 12px, Inter-400
- **Button Text**: 14px, Rajdhani-600, uppercase, tracking-wider

All typography renders in safety orange (#FF6600) on camo backgrounds.

---

## Core Components

### 1. Tactical Radar Display (Center-Dominant)
**Dimensions**: 400px diameter on desktop, 90vw on mobile (max 360px)
**Structure**:
- Circular radar face with camo-textured background
- Concentric range rings (100m, 250m, 500m, 1km) in orange at 30% opacity
- Cardinal direction markers (N, E, S, W) in bold orange
- Sweeping scan line animation (2-second rotation, optional toggle)
- Hunter position dots sized by proximity (16px-32px)
- Central crosshair representing user position
- Distance scale labels at ring intersections
- Bearing indicators with degree markings every 30°
**Border**: 4px solid orange with 2px inset shadow

### 2. Top Tactical HUD Bar
**Height**: 72px, full-width
**Background**: Semi-transparent camo (90% opacity)
**Layout**:
- **Left**: App emblem (48px tactical badge icon) + "HUNTER RADAR" (H1 typography)
- **Center**: Active hunters count badge (orange pill: "12 ACTIVE")
- **Right**: Grid toggle (satellite/terrain), boundary tool button, settings gear
**Border**: Bottom border 2px solid orange at 20% opacity

### 3. Hunter Status Panel (Floating Left)
**Width**: 340px on desktop, full-width drawer on mobile
**Position**: Top-left corner with 16px offset
**Background**: Camo pattern 85% opacity with subtle blur
**Structure**:
- Header: "TRACKED HUNTERS" + real-time update indicator (pulsing dot)
- Scrollable list (max-height 70vh) with custom orange scrollbar
- Each hunter card:
  - Callsign/ID (Rajdhani-600, 16px)
  - Distance readout (Roboto Mono-700, 20px, orange)
  - Bearing with directional arrow (→ ↑ ← ↓)
  - Last ping timestamp ("2m 14s")
  - Status bar: Green "ACTIVE" | Yellow "IDLE" | Red "ALERT"
- Card spacing: gap-3, p-4 internal padding
- Subtle orange border-left (4px) on hover

### 4. Map Position Markers
**User Marker**:
- 48px diameter circular target reticle
- Pulsing orange glow animation (1.5s interval)
- Directional chevron showing heading
- Drop shadow for elevation above map

**Hunter Markers**:
- Distance-scaled circles (24px-40px based on proximity)
- Solid orange fill with camo-pattern center
- Callsign label above marker (12px, Rajdhani-600)
- Connecting line to radar center when selected

### 5. Zoom & Controls Panel (Floating Right)
**Width**: 64px
**Position**: Top-right with 16px offset
**Vertical Stack**:
- Zoom In (+) button (56px × 56px)
- Zoom Out (-) button
- Layer toggle (map/satellite icons)
- Center location (crosshair target)
- 3D tilt toggle (perspective icon)
**Button Style**: Camo background, orange icon/text, 2px orange border
**Spacing**: gap-4 between buttons

### 6. Boundary Drawing Mode
**Activation**: Toggle via top bar button
**Overlay**: Full-screen semi-transparent camo (50% opacity)
**Tools**:
- Floating instruction panel (center-top): "TAP TO SET WAYPOINTS"
- Vertex markers (24px orange circles) at polygon corners
- Distance measurements along edges (Roboto Mono)
- Area calculation displayed (acres/hectares)
- Action buttons (bottom-center): "CONFIRM BOUNDARY" (orange fill), "CANCEL" (orange outline)

### 7. Alert Banner System
**Position**: Top-center, below HUD bar
**Alert Card**:
- Width: Max 480px
- Background: Solid white with orange left-border (6px)
- Icon: Warning triangle or info circle (32px, orange)
- Text: Black for maximum contrast against white
- Dismiss X button (top-right)
- Auto-dismiss: 6 seconds
- Stacking: gap-3 between multiple alerts

### 8. Mobile Tactical Drawer
**Collapsed**: 96px peek with orange handle bar
**Expanded**: 65% screen height slide-up
**Contents**:
- Mini radar display (220px diameter)
- Quick stats grid (2×2: Active Hunters, Area Size, Last Update, Battery)
- Scrollable hunter list (condensed cards)
**Background**: Full camo with 95% opacity

---

## Navigation & Interaction

**Primary Action (FAB)**:
- Position: Bottom-right, 16px offset
- Size: 64px diameter
- Icon: Polygon drawing tool (32px)
- Background: Solid orange, camo icon
- Shadow: Elevated 8px for prominence

**Touch Targets**: Minimum 48px × 48px for glove compatibility

**Gestures**:
- Pinch zoom on radar/map
- Two-finger rotate to adjust compass orientation
- Swipe up drawer to expand
- Long-press markers for details

---

## Icon System

**Library**: Heroicons (CDN - Outline style)
**Sizes**: 20px (small), 24px (standard), 32px (large markers)
**Color**: All icons render in safety orange (#FF6600)

**Required Icons**:
- Target/crosshair, compass, map layers, polygon draw, warning triangle, settings, menu, location pin, plus/minus (zoom), close (X), filter funnel, refresh

---

## Responsive Breakpoints

**Mobile (< 768px)**:
- Full-screen radar, bottom drawer, hamburger menu
- Radar: 90vw diameter (max 360px)
- Single-column hunter list

**Tablet (768px-1024px)**:
- Floating panels with reduced widths
- Radar: 340px diameter
- Left panel: 280px

**Desktop (>1024px)**:
- Full tactical HUD layout
- Radar: 400px diameter
- Left panel: 340px persistent

---

## Accessibility

- WCAG AAA contrast: Orange (#FF6600) on camo meets 7:1 ratio
- Alerts use white backgrounds for critical contrast
- Touch targets: 48px minimum
- Keyboard navigation: Tab through all controls
- Screen reader: ARIA labels on all markers ("Hunter Bravo, 247 meters northeast")
- Focus indicators: 3px orange outline with 2px offset
- Alternative to radar: List view with sortable columns

---

## Animation

**Minimal Military Efficiency**:
- Radar sweep line: 2-second rotation (toggle off for battery)
- Position pulse: 1.5-second fade (current user only)
- Alert slide-down: 200ms ease-out
- Panel transitions: 250ms ease-in-out
- NO decorative animations

---

## Images

**No Hero Images**: This is a pure utility interface where the radar/map IS the primary visual.

**Tactical Badges/Emblems**:
- App logo: 48px circular badge (crosshair + woodland camo texture)
- Hunter avatars: 40px circles with initials if no photo provided
- Background pattern: Seamless woodland camo SVG tile

**Texture Overlays**:
- Subtle noise (5% opacity) on all panels for tactical texture
- Camo patterns as CSS backgrounds or SVG patterns, not raster images