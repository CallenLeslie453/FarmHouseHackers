import os
import json
from datetime import datetime
from typing import List, Optional, Dict, Any

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

import google.generativeai as genai

# ──────────────────────────────────────────────────────────────────────────────
# BOOTSTRAP
# ──────────────────────────────────────────────────────────────────────────────
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise RuntimeError("Missing GEMINI_API_KEY. Add it to Replit Secrets.")

genai.configure(api_key=GEMINI_API_KEY)

EMBED_MODEL = "models/text-embedding-004"
GEN_MODEL = "gemini-1.5-flash"  # fast & cheap; use 1.5-pro if you have quota

DATA_DIR = "./data"
os.makedirs(DATA_DIR, exist_ok=True)
CHUNKS_PATH = os.path.join(DATA_DIR, "chunks.json")      # metadata + text
EMBEDS_PATH = os.path.join(DATA_DIR, "embeddings.npy")   # np.float32 array

def _load_store():
    if os.path.exists(CHUNKS_PATH):
        with open(CHUNKS_PATH, "r", encoding="utf-8") as f:
            chunks = json.load(f)
    else:
        chunks = []

    if os.path.exists(EMBEDS_PATH):
        embeds = np.load(EMBEDS_PATH)
    else:
        embeds = np.zeros((0, 768), dtype=np.float32)  # 768 dims for Gemini embeddings
    return chunks, embeds

def _save_store(chunks, embeds):
    with open(CHUNKS_PATH, "w", encoding="utf-8") as f:
        json.dump(chunks, f, ensure_ascii=False, indent=2)
    np.save(EMBEDS_PATH, embeds.astype(np.float32))

chunks_store, embed_store = _load_store()

# ──────────────────────────────────────────────────────────────────────────────
# FASTAPI
# ──────────────────────────────────────────────────────────────────────────────
app = FastAPI(title="Regulation Coach (Gemini RAG)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

# ──────────────────────────────────────────────────────────────────────────────
# SCHEMAS
# ──────────────────────────────────────────────────────────────────────────────
class IngestDoc(BaseModel):
    title: str
    source_url: Optional[str] = None
    jurisdiction: str = "Oklahoma"
    doc_version: Optional[str] = None
    last_reviewed: Optional[str] = None
    text: str

class AskRequest(BaseModel):
    question: str
    location_hint: Optional[str] = None
    species: Optional[str] = None
    filters: Dict[str, Any] = Field(default_factory=dict)
    top_k: int = 8

class AskResponse(BaseModel):
    answer: str
    citations: List[Dict[str, Any]]
    confidence_note: Optional[str] = None

# ──────────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────────
def chunk_text(s: str, max_chars: int = 1400, overlap: int = 200) -> List[str]:
    """Simple char-based chunking to keep it dependency-free."""
    s = s.strip()
    out = []
    i = 0
    while i < len(s):
        j = min(len(s), i + max_chars)
        out.append(s[i:j])
        i = j - overlap
        if i < 0:
            i = 0
        if i >= len(s):
            break
    # de-dup last overlap if it happens
    return [x for i, x in enumerate(out) if i == 0 or x != out[i-1]]

def embed_texts(texts: List[str]) -> np.ndarray:
    """Call Gemini embeddings for a batch of strings."""
    # google-generativeai Py SDK supports list input with embed_content
    vecs = []
    for t in texts:
        res = genai.embed_content(model=EMBED_MODEL, content=t)
        vecs.append(np.array(res["embedding"], dtype=np.float32))
    return np.vstack(vecs)

def cosine_sim(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-10)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-10)
    return np.dot(a_norm, b_norm.T)

def filter_chunks(meta_filters: Dict[str, Any]):
    """Yield (idx, chunk) matching simple equality filters on metadata."""
    for i, ch in enumerate(chunks_store):
        ok = True
        for k, v in meta_filters.items():
            if k not in ch["meta"] or str(ch["meta"][k]).lower() != str(v).lower():
                ok = False
                break
        if ok:
            yield i, ch

def select_top_k(query_vec: np.ndarray, mask_indices: List[int], k: int):
    """Compute cosine sim against masked subset; return top indices + scores."""
    if len(mask_indices) == 0:
        return [], []
    sub = embed_store[mask_indices]
    q = query_vec.reshape(1, -1)
    sims = cosine_sim(q, sub).ravel()
    order = np.argsort(-sims)[:k]
    top_global = [mask_indices[i] for i in order]
    top_scores = [float(sims[i]) for i in order]
    return top_global, top_scores

# ──────────────────────────────────────────────────────────────────────────────
# PLACEHOLDER PROMPT TEMPLATES (EDIT THESE!)
# ──────────────────────────────────────────────────────────────────────────────
SYSTEM_RULES = """
You are a safety- and compliance-first outdoor regulations assistant.
- You are NOT a lawyer. Provide informational guidance only.
- For any legal uncertainty, say you’re uncertain and point to official sources.
- Follow these ethics: safety, legality, landowner permission, visibility, species identification.
- If the user’s request could be unsafe or illegal, refuse and steer to official guidance.
- Always include brief, plain-English citations (title + page/section) from provided sources.
- Prefer Oklahoma-specific content when available.
- Keep answers concise for field use; avoid speculation.
- End with a short reminder: <<ADD YOUR SHORT SAFETY REMINDER HERE>>.
"""

ANSWER_FORMAT_HINT = """
Return:
1) A concise answer (2–5 sentences).
2) "What the rule says": bullet points quoting the relevant lines (short).
3) "What to do in the field": 2–3 lawful, safety-first steps.
4) "Citations": list title + page/section (from the provided context).
If confidence is low or sources conflict, clearly say so.
"""

# ──────────────────────────────────────────────────────────────────────────────
# ROUTES
# ──────────────────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"ok": True, "chunks": len(chunks_store), "dims": int(embed_store.shape[1]) if embed_store.size else 0}

@app.post("/regcoach/ingest")
def ingest(doc: IngestDoc):
    """Ingest ONE document: chunk → embed → persist."""
    global chunks_store, embed_store

    meta = {
        "title": doc.title,
        "source_url": doc.source_url or "",
        "jurisdiction": doc.jurisdiction,
        "doc_version": doc.doc_version or "v1",
        "last_reviewed": doc.last_reviewed or datetime.utcnow().date().isoformat(),
        "ingested_at": datetime.utcnow().isoformat()
    }

    parts = chunk_text(doc.text, max_chars=1400, overlap=200)
    if not parts:
        raise HTTPException(400, "No text chunks produced.")

    vecs = embed_texts(parts)  # (n, 768)

    start_idx = len(chunks_store)
    for i, p in enumerate(parts):
        chunks_store.append({
            "id": f"{doc.title}:{start_idx+i}",
            "text": p,
            "meta": meta
        })

    if embed_store.size == 0:
        embed_store = vecs
    else:
        embed_store = np.vstack([embed_store, vecs])

    _save_store(chunks_store, embed_store)

    return {
        "message": "Ingested",
        "chunks_added": len(parts),
        "doc_meta": meta
    }

@app.post("/regcoach/ask", response_model=AskResponse)
def ask(req: AskRequest):
    """Embed question → retrieve top chunks → ask Gemini with citations."""
    if len(chunks_store) == 0:
        raise HTTPException(400, "No content ingested yet.")

    # 1) Embed the user question (optionally enrich with hints)
    enriched_q = req.question
    if req.location_hint:
        enriched_q += f"\n[Location hint: {req.location_hint}]"
    if req.species:
        enriched_q += f"\n[Species: {req.species}]"

    q_vec = embed_texts([enriched_q])[0]  # (768,)

    # 2) Mask by filters (e.g., {"jurisdiction":"Oklahoma"})
    mask = [i for i, _ in filter_chunks(req.filters)] if req.filters else list(range(len(chunks_store)))
    if len(mask) == 0:
        return AskResponse(
            answer="I don't have matching sources for those filters. Try loosening your filters or ingest more Oklahoma materials.",
            citations=[],
            confidence_note="No chunks matched the filters."
        )

    # 3) Top-K retrieve
    top_idx, scores = select_top_k(q_vec, mask, req.top_k)
    selected = [chunks_store[i] for i in top_idx]

    # Build a compact context with citations
    context_blocks = []
    citations = []
    for ch, sc in zip(selected, scores):
        meta = ch["meta"]
        cite = {
            "title": meta.get("title", ""),
            "source_url": meta.get("source_url", ""),
            "jurisdiction": meta.get("jurisdiction", ""),
            "last_reviewed": meta.get("last_reviewed", ""),
            "doc_version": meta.get("doc_version", ""),
            "similarity": round(sc, 3)
        }
        citations.append(cite)
        ctx = (
            f"[Source: {cite['title']} | {cite['jurisdiction']} | last reviewed {cite['last_reviewed']}]\n"
            f"{ch['text']}"
        )
        context_blocks.append(ctx)

    context_text = "\n\n---\n\n".join(context_blocks)

    # 4) Compose Gemini prompt with your placeholders
    user_prompt = f"""
<<ROLE/SCOPE>>
You answer questions about outdoor/hunting regulations with a focus on Oklahoma.
Remember: <<ADD YOUR COMPLIANCE DISCLAIMER HERE>>.

<<USER QUESTION>>
{req.question}

<<CONTEXT (Cite only from below)>>
{context_text}

<<FORMAT>>
{ANSWER_FORMAT_HINT}
"""

    # 5) Call Gemini for the answer
    model = genai.GenerativeModel(GEN_MODEL)
    result = model.generate_content([
        {"role": "user", "text": SYSTEM_RULES.strip()},
        {"role": "user", "text": user_prompt.strip()}
    ])
    answer_text = (result.text or "").strip()

    # 6) Confidence heuristic (super simple: average similarity)
    conf = None
    if scores:
        avg = float(np.mean(scores))
        if avg >= 0.75:
            conf = "High"
        elif avg >= 0.55:
            conf = "Medium"
        else:
            conf = "Low"

    note = f"Confidence: {conf}. This is informational, not legal advice. Please verify with official sources and posted signage."
    return AskResponse(answer=answer_text, citations=citations, confidence_note=note)
