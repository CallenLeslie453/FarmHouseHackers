import { useState, useEffect } from "react";
import type { Position } from "@shared/schema";

interface GeolocationState {
  position: Position | null;
  error: string | null;
  loading: boolean;
}

export function useGeolocation(watch = true) {
  const [state, setState] = useState<GeolocationState>({
    position: null,
    error: null,
    loading: true,
  });

  useEffect(() => {
    if (!navigator.geolocation) {
      setState({
        position: null,
        error: "Geolocation is not supported by your browser",
        loading: false,
      });
      return;
    }

    const handleSuccess = (pos: GeolocationPosition) => {
      setState({
        position: {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        },
        error: null,
        loading: false,
      });
    };

    const handleError = (err: GeolocationPositionError) => {
      setState({
        position: null,
        error: err.message,
        loading: false,
      });
    };

    const options = {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0,
    };

    let watchId: number | undefined;

    if (watch) {
      watchId = navigator.geolocation.watchPosition(
        handleSuccess,
        handleError,
        options
      );
    } else {
      navigator.geolocation.getCurrentPosition(
        handleSuccess,
        handleError,
        options
      );
    }

    return () => {
      if (watchId !== undefined) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [watch]);

  return state;
}
