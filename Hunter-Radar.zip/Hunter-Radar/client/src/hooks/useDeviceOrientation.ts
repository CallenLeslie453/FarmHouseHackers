import { useState, useEffect } from "react";

export function useDeviceOrientation() {
  const [heading, setHeading] = useState<number>(0);
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    if ('DeviceOrientationEvent' in window) {
      setSupported(true);

      const handleOrientation = (event: DeviceOrientationEvent) => {
        if (event.alpha !== null) {
          setHeading(360 - event.alpha);
        } else if ((event as any).webkitCompassHeading !== undefined) {
          setHeading((event as any).webkitCompassHeading);
        }
      };

      if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
        (DeviceOrientationEvent as any).requestPermission()
          .then((permissionState: string) => {
            if (permissionState === 'granted') {
              window.addEventListener('deviceorientation', handleOrientation);
            }
          })
          .catch(console.error);
      } else {
        window.addEventListener('deviceorientation', handleOrientation);
      }

      return () => {
        window.removeEventListener('deviceorientation', handleOrientation);
      };
    }
  }, []);

  return { heading, supported };
}
