import { setOptions, importLibrary } from "@googlemaps/js-api-loader";

let isConfigured = false;

export function configureGoogleMaps() {
  if (!isConfigured) {
    const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";
    console.log("Configuring Google Maps with API key:", apiKey ? `${apiKey.substring(0, 10)}...` : "MISSING");
    setOptions({
      apiKey,
      version: "weekly",
    });
    isConfigured = true;
  }
}

export async function loadGoogleMaps() {
  configureGoogleMaps();
  await importLibrary("maps");
  await importLibrary("marker");
  await importLibrary("geometry");
  await importLibrary("drawing");
}

export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371e3;
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export function calculateBearing(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x =
    Math.cos(φ1) * Math.sin(φ2) -
    Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  const θ = Math.atan2(y, x);

  return ((θ * 180) / Math.PI + 360) % 360;
}

export function formatDistance(meters: number): string {
  if (meters < 1000) {
    return `${Math.round(meters)}m`;
  }
  return `${(meters / 1000).toFixed(1)}km`;
}

export function getDistanceCategory(
  meters: number
): "immediate" | "near" | "far" {
  if (meters <= 100) return "immediate";
  if (meters <= 250) return "near";
  return "far";
}

export function isPointNearBoundary(
  point: { lat: number; lng: number },
  boundaryCoords: { lat: number; lng: number }[],
  thresholdMeters: number
): { isNear: boolean; distance: number } {
  let minDistance = Infinity;

  for (let i = 0; i < boundaryCoords.length; i++) {
    const coord = boundaryCoords[i];
    const distance = calculateDistance(point.lat, point.lng, coord.lat, coord.lng);
    
    if (distance < minDistance) {
      minDistance = distance;
    }

    const nextCoord = i < boundaryCoords.length - 1 
      ? boundaryCoords[i + 1] 
      : boundaryCoords[0];
    
    const distanceToSegment = pointToSegmentDistance(point, coord, nextCoord);
    if (distanceToSegment < minDistance) {
      minDistance = distanceToSegment;
    }
  }

  return {
    isNear: minDistance <= thresholdMeters,
    distance: minDistance
  };
}

function pointToSegmentDistance(
  point: { lat: number; lng: number },
  segStart: { lat: number; lng: number },
  segEnd: { lat: number; lng: number }
): number {
  const distToStart = calculateDistance(point.lat, point.lng, segStart.lat, segStart.lng);
  const distToEnd = calculateDistance(point.lat, point.lng, segEnd.lat, segEnd.lng);
  const segLength = calculateDistance(segStart.lat, segStart.lng, segEnd.lat, segEnd.lng);
  
  if (segLength === 0) return distToStart;

  const t = Math.max(0, Math.min(1, 
    ((point.lat - segStart.lat) * (segEnd.lat - segStart.lat) +
     (point.lng - segStart.lng) * (segEnd.lng - segStart.lng)) /
    (segLength * segLength)
  ));

  const projLat = segStart.lat + t * (segEnd.lat - segStart.lat);
  const projLng = segStart.lng + t * (segEnd.lng - segStart.lng);

  return calculateDistance(point.lat, point.lng, projLat, projLng);
}
