import type { HunterPosition, BoundaryPolygon } from "@shared/schema";

const OFFLINE_POSITIONS_KEY = "hunter_radar_offline_positions";
const CACHED_HUNTERS_KEY = "hunter_radar_cached_hunters";
const CACHED_BOUNDARIES_KEY = "hunter_radar_cached_boundaries";

export function queueOfflinePosition(position: Partial<HunterPosition>) {
  try {
    const queue = getOfflinePositionQueue();
    queue.push({ ...position, timestamp: Date.now() });
    localStorage.setItem(OFFLINE_POSITIONS_KEY, JSON.stringify(queue));
  } catch (error) {
    console.error("Error queuing offline position:", error);
  }
}

export function getOfflinePositionQueue(): Array<Partial<HunterPosition> & { timestamp: number }> {
  try {
    const data = localStorage.getItem(OFFLINE_POSITIONS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function clearOfflinePositionQueue() {
  localStorage.removeItem(OFFLINE_POSITIONS_KEY);
}

export function cacheHunters(hunters: HunterPosition[]) {
  try {
    localStorage.setItem(CACHED_HUNTERS_KEY, JSON.stringify(hunters));
  } catch (error) {
    console.error("Error caching hunters:", error);
  }
}

export function getCachedHunters(): HunterPosition[] {
  try {
    const data = localStorage.getItem(CACHED_HUNTERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function cacheBoundaries(boundaries: BoundaryPolygon[]) {
  try {
    localStorage.setItem(CACHED_BOUNDARIES_KEY, JSON.stringify(boundaries));
  } catch (error) {
    console.error("Error caching boundaries:", error);
  }
}

export function getCachedBoundaries(): BoundaryPolygon[] {
  try {
    const data = localStorage.getItem(CACHED_BOUNDARIES_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}
