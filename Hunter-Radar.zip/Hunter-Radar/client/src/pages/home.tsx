import { useState, useCallback, useEffect } from "react";
import { RadarDisplay } from "@/components/RadarDisplay";
import { HunterList } from "@/components/HunterList";
import { ControlBar } from "@/components/ControlBar";
import { AlertBanner } from "@/components/AlertBanner";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import type { HunterPosition, Position, WSMessage, BoundaryPolygon } from "@shared/schema";
import { Loader2, MapPin } from "lucide-react";
import { calculateDistance, getDistanceCategory, isPointNearBoundary } from "@/lib/maps";
import { useToast } from "@/hooks/use-toast";
import { cacheHunters, cacheBoundaries, getCachedHunters, getCachedBoundaries } from "@/lib/offline";

export default function Home() {
  const [hunters, setHunters] = useState<HunterPosition[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string>("");
  const [userName, setUserName] = useState("");
  const [isJoined, setIsJoined] = useState(false);
  const [sessionStartTime, setSessionStartTime] = useState<Date | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [alerts, setAlerts] = useState<
    Array<{ id: string; type: "warning" | "info"; message: string }>
  >([]);
  const [boundaries, setBoundaries] = useState<BoundaryPolygon[]>([]);

  const { position, loading: geoLoading, error: geoError } = useGeolocation(isJoined);
  const { toast } = useToast();

  useEffect(() => {
    const cached = getCachedHunters();
    if (cached.length > 0 && hunters.length === 0) {
      setHunters(cached);
    }
  }, []);

  useEffect(() => {
    const cached = getCachedBoundaries();
    if (cached.length > 0 && boundaries.length === 0) {
      setBoundaries(cached);
    }
  }, []);

  useEffect(() => {
    const loadBoundaries = async () => {
      try {
        const response = await fetch("/api/boundaries");
        if (response.ok) {
          const loadedBoundaries = await response.json();
          setBoundaries(loadedBoundaries);
        }
      } catch (error) {
        console.error("Error loading boundaries:", error);
      }
    };

    loadBoundaries();
  }, []);

  const handleWSMessage = useCallback((message: WSMessage) => {
    if (message.type === "position_update") {
      setHunters((prev) => {
        const existing = prev.find((h) => h.id === message.data.id);
        if (existing) {
          return prev.map((h) =>
            h.id === message.data.id ? { ...h, ...message.data } : h
          );
        }
        return [...prev, message.data];
      });
    } else if (message.type === "hunter_joined") {
      if (message.data.id) {
        setCurrentUserId(message.data.id);
      }
      setHunters((prev) => [...prev, message.data]);
    } else if (message.type === "hunter_left") {
      setHunters((prev) => prev.filter((h) => h.id !== message.data.id));
    }
  }, []);

  const { isConnected, sendMessage } = useWebSocket(handleWSMessage);

  useEffect(() => {
    if (isJoined && position && currentUserId) {
      sendMessage({
        type: "position_update",
        data: {
          id: currentUserId,
          name: userName,
          lat: position.lat,
          lng: position.lng,
          lastUpdate: new Date().toISOString(),
        },
      });
    }
  }, [position, isJoined, currentUserId, userName, sendMessage]);

  useEffect(() => {
    cacheHunters(hunters);
  }, [hunters]);

  useEffect(() => {
    cacheBoundaries(boundaries);
  }, [boundaries]);

  useEffect(() => {
    if (!position || !isJoined) return;

    const otherHunters = hunters.filter((h) => h.id !== currentUserId);
    const closeHunters = otherHunters.filter((hunter) => {
      const distance = calculateDistance(
        position.lat,
        position.lng,
        hunter.lat,
        hunter.lng
      );
      return getDistanceCategory(distance) === "immediate";
    });

    if (closeHunters.length > 0) {
      const newAlert = {
        id: `alert-${Date.now()}`,
        type: "warning" as const,
        message: `Warning: ${closeHunters.length} hunter(s) within 100m`,
      };

      setAlerts((prev) => {
        const exists = prev.some(
          (a) =>
            a.message.includes("hunter(s) within 100m") &&
            Date.now() - parseInt(a.id.split("-")[1]) < 5000
        );
        if (!exists) {
          return [...prev, newAlert];
        }
        return prev;
      });
    }
  }, [hunters, position, currentUserId, isJoined]);

  useEffect(() => {
    if (!position || !isJoined || boundaries.length === 0) return;

    const BOUNDARY_WARNING_THRESHOLD = 200;

    for (const boundary of boundaries) {
      const { isNear, distance } = isPointNearBoundary(
        position,
        boundary.coordinates,
        BOUNDARY_WARNING_THRESHOLD
      );

      if (isNear) {
        const newAlert = {
          id: `boundary-${boundary.id}-${Date.now()}`,
          type: "info" as const,
          message: `Approaching boundary: ${boundary.name} (${Math.round(distance)}m away)`,
        };

        setAlerts((prev) => {
          const exists = prev.some(
            (a) =>
              a.message.includes(boundary.name) &&
              Date.now() - parseInt(a.id.split("-")[2]) < 10000
          );
          if (!exists) {
            return [...prev, newAlert];
          }
          return prev;
        });
      }
    }
  }, [position, boundaries, isJoined]);

  const handleJoin = () => {
    if (userName.trim() && position) {
      const now = new Date();
      const id = Date.now().toString();
      setCurrentUserId(id);
      sendMessage({
        type: "hunter_joined",
        data: {
          id,
          name: userName.trim(),
          lat: position.lat,
          lng: position.lng,
          lastUpdate: now.toISOString(),
        },
      });
      setIsJoined(true);
      setSessionStartTime(now);
    }
  };

  const handleCheckOut = () => {
    sendMessage({
      type: "hunter_left",
      data: { id: currentUserId },
    });

    setIsJoined(false);
    setCurrentUserId("");
    setSessionStartTime(null);
    setUserName("");
  };


  const handleDismissAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  const handleImportGIS = async (source: "blm" | "usfs") => {
    if (!position) {
      toast({
        title: "Location required",
        description: "Please enable location access to import nearby boundaries",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch("/api/boundaries/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          source,
          lat: position.lat,
          lng: position.lng,
          radiusMiles: 50,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Boundaries imported",
          description: `Loaded ${data.imported} ${source.toUpperCase()} boundaries`,
        });

        if (data.boundaries) {
          setBoundaries((prev) => [...prev, ...data.boundaries]);
        }
      } else {
        throw new Error("Import failed");
      }
    } catch (error) {
      console.error("Error importing GIS data:", error);
      toast({
        title: "Import failed",
        description: "Failed to import boundaries from GIS source",
        variant: "destructive",
      });
    }
  };

  if (!isJoined) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-4">
        <Card className="w-full max-w-md p-6 space-y-4">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <MapPin className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Hunter Radar</h1>
            <p className="text-sm text-muted-foreground">
              Track hunter locations in real-time for safety
            </p>
          </div>

          {geoLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
              <span className="ml-2 text-sm text-muted-foreground">
                Getting your location...
              </span>
            </div>
          ) : geoError ? (
            <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-md">
              <p className="text-sm text-destructive">{geoError}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Please enable location access to use this app
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">
                  Your Name
                </label>
                <Input
                  type="text"
                  placeholder="Enter your name"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleJoin()}
                  data-testid="input-username"
                />
              </div>

              <Button
                className="w-full"
                onClick={handleJoin}
                disabled={!userName.trim() || !position || !isConnected}
                data-testid="button-join"
              >
                {isConnected ? "Join Hunting Area" : "Connecting..."}
              </Button>

              {position && (
                <p className="text-xs text-center text-muted-foreground">
                  Location: {position.lat.toFixed(4)}, {position.lng.toFixed(4)}
                </p>
              )}
            </div>
          )}
        </Card>
      </div>
    );
  }

  const currentPosition = position || { lat: 0, lng: 0 };

  return (
    <div className="flex flex-col h-screen">
      <ControlBar
        onToggleDrawing={() => setIsDrawing(!isDrawing)}
        isDrawing={isDrawing}
        onImportGIS={handleImportGIS}
        onCheckOut={handleCheckOut}
        sessionStartTime={sessionStartTime}
      />

      <AlertBanner alerts={alerts} onDismiss={handleDismissAlert} />

      <div className="flex-1 flex overflow-hidden">
        <aside className="hidden lg:block w-80 border-r overflow-hidden">
          <HunterList
            currentPosition={currentPosition}
            hunters={hunters}
            currentUserId={currentUserId}
            className="h-full border-0 rounded-none"
          />
        </aside>

        <main className="flex-1 relative flex items-center justify-center p-4">
          <RadarDisplay
            currentPosition={currentPosition}
            hunters={hunters}
            currentUserId={currentUserId}
            fullScreen={true}
            className="max-w-2xl"
          />
        </main>
      </div>

      <div className="lg:hidden border-t bg-card p-2">
        <HunterList
          currentPosition={currentPosition}
          hunters={hunters}
          currentUserId={currentUserId}
          className="max-h-32 overflow-y-auto"
        />
      </div>
    </div>
  );
}
