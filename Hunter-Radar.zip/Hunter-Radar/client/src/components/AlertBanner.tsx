import { useEffect, useState } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Info, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AlertMessage {
  id: string;
  type: "warning" | "info";
  message: string;
  autoClose?: boolean;
}

interface AlertBannerProps {
  alerts: AlertMessage[];
  onDismiss: (id: string) => void;
}

export function AlertBanner({ alerts, onDismiss }: AlertBannerProps) {
  useEffect(() => {
    const timers: NodeJS.Timeout[] = [];

    alerts.forEach((alert) => {
      if (alert.autoClose !== false) {
        const timer = setTimeout(() => {
          onDismiss(alert.id);
        }, 8000);
        timers.push(timer);
      }
    });

    return () => {
      timers.forEach((timer) => clearTimeout(timer));
    };
  }, [alerts, onDismiss]);

  if (alerts.length === 0) return null;

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4 space-y-2">
      {alerts.map((alert) => (
        <Alert
          key={alert.id}
          variant={alert.type === "warning" ? "destructive" : "default"}
          className="shadow-lg animate-in slide-in-from-top"
          data-testid={`alert-${alert.id}`}
        >
          <div className="flex items-start gap-3">
            {alert.type === "warning" ? (
              <AlertTriangle className="h-5 w-5 mt-0.5" />
            ) : (
              <Info className="h-5 w-5 mt-0.5" />
            )}
            <AlertDescription className="flex-1">
              {alert.message}
            </AlertDescription>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 -mt-1 -mr-2"
              onClick={() => onDismiss(alert.id)}
              data-testid={`button-dismiss-${alert.id}`}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </Alert>
      ))}
    </div>
  );
}
