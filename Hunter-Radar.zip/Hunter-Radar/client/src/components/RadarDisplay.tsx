import { useEffect, useRef } from "react";
import type { HunterPosition, Position } from "@shared/schema";
import { calculateDistance, calculateBearing, getDistanceCategory } from "@/lib/maps";
import { Card } from "@/components/ui/card";
import { useDeviceOrientation } from "@/hooks/useDeviceOrientation";
import { Compass } from "lucide-react";

interface RadarDisplayProps {
  currentPosition: Position;
  hunters: HunterPosition[];
  currentUserId?: string;
  className?: string;
  fullScreen?: boolean;
}

export function RadarDisplay({
  currentPosition,
  hunters,
  currentUserId,
  className,
  fullScreen = false,
}: RadarDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { heading, supported } = useDeviceOrientation();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const size = canvas.width;
    const center = size / 2;
    const maxRadius = center - 20;

    ctx.clearRect(0, 0, size, size);

    ctx.strokeStyle = "hsl(var(--border))";
    ctx.lineWidth = 1;
    ctx.setLineDash([2, 2]);

    [100, 250, 500].forEach((distance, i) => {
      const radius = ((i + 1) / 3) * maxRadius;
      ctx.beginPath();
      ctx.arc(center, center, radius, 0, 2 * Math.PI);
      ctx.stroke();

      ctx.fillStyle = "hsl(var(--muted-foreground))";
      ctx.font = "10px var(--font-mono)";
      ctx.textAlign = "center";
      ctx.fillText(`${distance}m`, center, center - radius + 12);
    });

    ctx.setLineDash([]);

    const headingRad = (heading * Math.PI) / 180;
    
    ["N", "E", "S", "W"].forEach((direction, i) => {
      const directionAngle = (i * Math.PI) / 2 - Math.PI / 2;
      const adjustedAngle = directionAngle - headingRad;
      const x = center + Math.cos(adjustedAngle) * (maxRadius + 10);
      const y = center + Math.sin(adjustedAngle) * (maxRadius + 10);

      ctx.fillStyle = i === 0 ? "#FF6600" : "hsl(var(--foreground))";
      ctx.font = i === 0 ? "bold 16px var(--font-sans)" : "14px var(--font-sans)";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(direction, x, y);
    });

    ctx.beginPath();
    ctx.arc(center, center, 6, 0, 2 * Math.PI);
    ctx.fillStyle = "#3b82f6";
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.stroke();

    const otherHunters = hunters.filter((h) => h.id !== currentUserId);

    otherHunters.forEach((hunter) => {
      const distance = calculateDistance(
        currentPosition.lat,
        currentPosition.lng,
        hunter.lat,
        hunter.lng
      );
      const bearing = calculateBearing(
        currentPosition.lat,
        currentPosition.lng,
        hunter.lat,
        hunter.lng
      );

      const category = getDistanceCategory(distance);
      const scaledDistance = Math.min(distance, 500);
      const radius = (scaledDistance / 500) * maxRadius;

      const adjustedBearing = bearing - heading;
      const angle = ((adjustedBearing - 90) * Math.PI) / 180;
      const x = center + Math.cos(angle) * radius;
      const y = center + Math.sin(angle) * radius;

      const colors = {
        immediate: "#ef4444",
        near: "#f59e0b",
        far: "#22c55e",
      };

      ctx.beginPath();
      ctx.arc(x, y, 5, 0, 2 * Math.PI);
      ctx.fillStyle = colors[category];
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = "hsl(var(--foreground))";
      ctx.font = "10px var(--font-sans)";
      ctx.textAlign = "center";
      ctx.fillText(hunter.name.charAt(0), x, y - 12);
    });
  }, [currentPosition, hunters, currentUserId, heading]);

  const canvasSize = fullScreen ? 600 : 280;

  return (
    <Card className={`p-4 ${className} ${fullScreen ? 'flex flex-col items-center justify-center' : ''}`} data-testid="radar-display">
      <div className="flex items-center justify-between mb-3">
        <h3 className={`font-bold uppercase tracking-wider ${fullScreen ? 'text-2xl' : 'text-sm'}`}>
          <Compass className={`inline mr-2 ${fullScreen ? 'h-6 w-6' : 'h-4 w-4'}`} />
          Radar
        </h3>
        {supported && (
          <div className="text-xs text-muted-foreground">
            {Math.round(heading)}° 
          </div>
        )}
      </div>
      <canvas
        ref={canvasRef}
        width={canvasSize}
        height={canvasSize}
        className="w-full h-auto max-w-full"
      />
      <div className={`mt-3 space-y-1 ${fullScreen ? 'flex gap-6' : ''}`}>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-3 h-3 rounded-full bg-distance-immediate" />
          <span className="text-muted-foreground font-mono">0-100m</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-3 h-3 rounded-full bg-distance-near" />
          <span className="text-muted-foreground font-mono">100-250m</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-3 h-3 rounded-full bg-distance-far" />
          <span className="text-muted-foreground font-mono">250m+</span>
        </div>
      </div>
    </Card>
  );
}
