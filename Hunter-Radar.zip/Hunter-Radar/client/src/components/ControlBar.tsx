import { Button } from "@/components/ui/button";
import { Menu, Pencil, X, Download, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface ControlBarProps {
  onToggleDrawing?: () => void;
  isDrawing: boolean;
  onImportGIS?: (source: "blm" | "usfs") => void;
  onCheckOut?: () => void;
  sessionStartTime?: Date | null;
}

export function ControlBar({ onToggleDrawing, isDrawing, onImportGIS, onCheckOut, sessionStartTime }: ControlBarProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [sessionDuration, setSessionDuration] = useState("");

  useEffect(() => {
    if (!sessionStartTime) return;

    const updateDuration = () => {
      const now = new Date();
      const diff = now.getTime() - sessionStartTime.getTime();
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      if (hours > 0) {
        setSessionDuration(`${hours}h ${minutes}m`);
      } else {
        setSessionDuration(`${minutes}m`);
      }
    };

    updateDuration();
    const interval = setInterval(updateDuration, 60000);

    return () => clearInterval(interval);
  }, [sessionStartTime]);

  return (
    <div className="h-16 bg-card border-b px-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              className="w-5 h-5 text-primary-foreground"
            >
              <circle cx="12" cy="12" r="3" fill="currentColor" />
              <path
                d="M12 2L12 8M12 16L12 22M2 12L8 12M16 12L22 12"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight">
              Hunter Radar
            </h1>
            <p className="text-xs text-muted-foreground hidden sm:block">
              {sessionDuration ? `Session: ${sessionDuration}` : "Real-time tracking"}
            </p>
          </div>
          {sessionDuration && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-primary/10 text-primary" data-testid="session-duration">
              <Clock className="h-3.5 w-3.5" />
              <span className="text-sm font-medium">{sessionDuration}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              size="default"
              data-testid="button-import-gis"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Import GIS</span>
            </Button>
          </DialogTrigger>
          <DialogContent data-testid="dialog-import-gis">
            <DialogHeader>
              <DialogTitle>Import Public Land Boundaries</DialogTitle>
              <DialogDescription>
                Import hunting land boundaries from government GIS data sources
              </DialogDescription>
            </DialogHeader>
            <div className="flex flex-col gap-3 pt-4">
              <Button
                onClick={() => {
                  onImportGIS?.("blm");
                  setShowImportDialog(false);
                }}
                data-testid="button-import-blm"
                className="justify-start"
              >
                <Download className="h-4 w-4 mr-2" />
                BLM Public Lands
                <span className="text-xs text-muted-foreground ml-auto">Bureau of Land Management</span>
              </Button>
              <Button
                onClick={() => {
                  onImportGIS?.("usfs");
                  setShowImportDialog(false);
                }}
                data-testid="button-import-usfs"
                className="justify-start"
              >
                <Download className="h-4 w-4 mr-2" />
                National Forests
                <span className="text-xs text-muted-foreground ml-auto">US Forest Service</span>
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <Button
          variant={isDrawing ? "default" : "outline"}
          size="default"
          onClick={onToggleDrawing}
          data-testid="button-toggle-drawing"
          className="gap-2"
        >
          {isDrawing ? (
            <>
              <X className="h-4 w-4" />
              <span className="hidden sm:inline">Cancel</span>
            </>
          ) : (
            <>
              <Pencil className="h-4 w-4" />
              <span className="hidden sm:inline">Draw Boundary</span>
            </>
          )}
        </Button>

        {sessionStartTime && (
          <Button
            variant="destructive"
            size="default"
            onClick={onCheckOut}
            data-testid="button-check-out"
            className="gap-2"
          >
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">Check Out</span>
          </Button>
        )}

        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowMenu(!showMenu)}
          data-testid="button-menu"
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
