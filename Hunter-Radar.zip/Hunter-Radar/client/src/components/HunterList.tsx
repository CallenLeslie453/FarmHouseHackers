import type { HunterPosition, Position } from "@shared/schema";
import { calculateDistance, calculateBearing, formatDistance, getDistanceCategory } from "@/lib/maps";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Navigation } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface HunterListProps {
  currentPosition: Position;
  hunters: HunterPosition[];
  currentUserId?: string;
  className?: string;
}

export function HunterList({
  currentPosition,
  hunters,
  currentUserId,
  className,
}: HunterListProps) {
  const otherHunters = hunters
    .filter((h) => h.id !== currentUserId)
    .map((hunter) => {
      const distance = calculateDistance(
        currentPosition.lat,
        currentPosition.lng,
        hunter.lat,
        hunter.lng
      );
      const bearing = calculateBearing(
        currentPosition.lat,
        currentPosition.lng,
        hunter.lat,
        hunter.lng
      );
      return { ...hunter, distance, bearing };
    })
    .sort((a, b) => a.distance - b.distance);

  const getDirectionArrow = (bearing: number): string => {
    const directions = ["↑", "↗", "→", "↘", "↓", "↙", "←", "↖"];
    const index = Math.round(bearing / 45) % 8;
    return directions[index];
  };

  const getCategoryColor = (category: "immediate" | "near" | "far") => {
    const colors = {
      immediate: "bg-distance-immediate",
      near: "bg-distance-near",
      far: "bg-distance-far",
    };
    return colors[category];
  };

  return (
    <Card className={`flex flex-col ${className}`} data-testid="hunter-list">
      <div className="p-4 border-b">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-muted-foreground" />
          <h2 className="text-lg font-semibold">Active Hunters</h2>
          <Badge variant="secondary" className="ml-auto">
            {otherHunters.length}
          </Badge>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {otherHunters.length === 0 ? (
          <div className="text-center py-8">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
            <p className="text-sm text-muted-foreground">
              No other hunters in the area
            </p>
          </div>
        ) : (
          otherHunters.map((hunter) => {
            const category = getDistanceCategory(hunter.distance);
            return (
              <Card
                key={hunter.id}
                className="p-3 hover-elevate"
                data-testid={`hunter-card-${hunter.id}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <div
                        className={`w-2 h-2 rounded-full ${getCategoryColor(category)}`}
                      />
                      <h3 className="font-semibold truncate">{hunter.name}</h3>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-mono font-bold">
                          {formatDistance(hunter.distance)}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          away
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Navigation className="h-3 w-3" />
                        <span className="font-mono">
                          {Math.round(hunter.bearing)}°
                        </span>
                        <span className="text-lg">
                          {getDirectionArrow(hunter.bearing)}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Updated{" "}
                        {formatDistanceToNow(new Date(hunter.lastUpdate), {
                          addSuffix: true,
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })
        )}
      </div>
    </Card>
  );
}
