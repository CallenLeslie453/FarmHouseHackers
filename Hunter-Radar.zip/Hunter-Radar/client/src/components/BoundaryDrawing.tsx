import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Check } from "lucide-react";
import type { Position } from "@shared/schema";

interface BoundaryDrawingProps {
  map: google.maps.Map | null;
  isActive: boolean;
  onComplete: (name: string, coordinates: Position[]) => void;
  onCancel: () => void;
}

export function BoundaryDrawing({
  map,
  isActive,
  onComplete,
  onCancel,
}: BoundaryDrawingProps) {
  const polygonRef = useRef<google.maps.Polygon | null>(null);
  const drawingManagerRef = useRef<google.maps.drawing.DrawingManager | null>(
    null
  );
  const [coordinates, setCoordinates] = useState<Position[]>([]);
  const [boundaryName, setBoundaryName] = useState("");
  const [showNameInput, setShowNameInput] = useState(false);

  useEffect(() => {
    if (!map || !isActive) {
      if (drawingManagerRef.current) {
        drawingManagerRef.current.setMap(null);
      }
      if (polygonRef.current) {
        polygonRef.current.setMap(null);
        polygonRef.current = null;
      }
      setCoordinates([]);
      setShowNameInput(false);
      return;
    }

    const loadDrawingLibrary = async () => {
      await google.maps.importLibrary("drawing");

      const drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: google.maps.drawing.OverlayType.POLYGON,
        drawingControl: false,
        polygonOptions: {
          fillColor: "#3b82f6",
          fillOpacity: 0.2,
          strokeColor: "#3b82f6",
          strokeWeight: 2,
          editable: true,
          draggable: false,
        },
      });

      drawingManager.setMap(map);
      drawingManagerRef.current = drawingManager;

      google.maps.event.addListener(
        drawingManager,
        "polygoncomplete",
        (polygon: google.maps.Polygon) => {
          polygonRef.current = polygon;
          const path = polygon.getPath();
          const coords: Position[] = [];

          for (let i = 0; i < path.getLength(); i++) {
            const point = path.getAt(i);
            coords.push({
              lat: point.lat(),
              lng: point.lng(),
            });
          }

          setCoordinates(coords);
          setShowNameInput(true);
          drawingManager.setDrawingMode(null);
        }
      );
    };

    loadDrawingLibrary();

    return () => {
      if (drawingManagerRef.current) {
        google.maps.event.clearInstanceListeners(drawingManagerRef.current);
        drawingManagerRef.current.setMap(null);
      }
      if (polygonRef.current) {
        polygonRef.current.setMap(null);
      }
    };
  }, [map, isActive]);

  const handleComplete = () => {
    if (coordinates.length > 0 && boundaryName.trim()) {
      onComplete(boundaryName, coordinates);
      setBoundaryName("");
      setShowNameInput(false);
      setCoordinates([]);
      if (polygonRef.current) {
        polygonRef.current.setMap(null);
        polygonRef.current = null;
      }
    }
  };

  if (!isActive) return null;

  return (
    <>
      <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 pointer-events-none" />

      {!showNameInput ? (
        <Card className="fixed top-24 left-1/2 -translate-x-1/2 z-50 p-4 shadow-lg">
          <p className="text-sm text-center">
            Click on the map to draw a boundary polygon
          </p>
        </Card>
      ) : (
        <Card className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 p-4 shadow-lg w-full max-w-md">
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium mb-1 block">
                Boundary Name
              </label>
              <Input
                type="text"
                placeholder="e.g., North Hunting Zone"
                value={boundaryName}
                onChange={(e) => setBoundaryName(e.target.value)}
                data-testid="input-boundary-name"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  onCancel();
                  setBoundaryName("");
                  setShowNameInput(false);
                  setCoordinates([]);
                  if (polygonRef.current) {
                    polygonRef.current.setMap(null);
                    polygonRef.current = null;
                  }
                }}
                data-testid="button-cancel-boundary"
              >
                Cancel
              </Button>
              <Button
                className="flex-1 gap-2"
                onClick={handleComplete}
                disabled={!boundaryName.trim()}
                data-testid="button-save-boundary"
              >
                <Check className="h-4 w-4" />
                Save Boundary
              </Button>
            </div>
          </div>
        </Card>
      )}
    </>
  );
}
