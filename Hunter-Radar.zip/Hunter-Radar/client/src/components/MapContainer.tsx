import { useEffect, useRef, useState } from "react";
import { loadGoogleMaps } from "@/lib/maps";
import type { Position, HunterPosition } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface MapContainerProps {
  center: Position;
  hunters: HunterPosition[];
  currentUserId?: string;
  onMapLoad?: (map: google.maps.Map) => void;
}

export function MapContainer({
  center,
  hunters,
  currentUserId,
  onMapLoad,
}: MapContainerProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<Map<string, google.maps.Marker>>(new Map());
  const safetyZonesRef = useRef<Map<string, google.maps.Circle>>(new Map());
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const SAFETY_ZONE_RADIUS = 100;

  useEffect(() => {
    if (!mapRef.current) return;

    const initMap = async () => {
      try {
        await loadGoogleMaps();

        const map = new google.maps.Map(mapRef.current!, {
          center,
          zoom: 15,
          mapTypeControl: true,
          mapTypeControlOptions: {
            position: google.maps.ControlPosition.TOP_RIGHT,
          },
          zoomControl: true,
          zoomControlOptions: {
            position: google.maps.ControlPosition.TOP_RIGHT,
          },
          streetViewControl: false,
          fullscreenControl: false,
        });

        mapInstanceRef.current = map;
        onMapLoad?.(map);
        setIsLoading(false);
      } catch (err) {
        console.error("Error loading Google Maps:", err);
        setError("Failed to load map");
        setIsLoading(false);
      }
    };

    initMap();
  }, []);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    map.setCenter(center);
  }, [center]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const existingMarkers = new Set(markersRef.current.keys());
    const currentHunterIds = new Set(hunters.map((h) => h.id));

    existingMarkers.forEach((id) => {
      if (!currentHunterIds.has(id)) {
        markersRef.current.get(id)?.setMap(null);
        markersRef.current.delete(id);
        safetyZonesRef.current.get(id)?.setMap(null);
        safetyZonesRef.current.delete(id);
      }
    });

    hunters.forEach((hunter) => {
      const isCurrentUser = hunter.id === currentUserId;
      let marker = markersRef.current.get(hunter.id);

      if (!marker) {
        marker = new google.maps.Marker({
          position: { lat: hunter.lat, lng: hunter.lng },
          map,
          title: hunter.name,
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: isCurrentUser ? 12 : 8,
            fillColor: isCurrentUser ? "#3b82f6" : "#ef4444",
            fillOpacity: 1,
            strokeColor: "#ffffff",
            strokeWeight: 2,
          },
          animation: isCurrentUser
            ? google.maps.Animation.BOUNCE
            : undefined,
        });

        const infoWindow = new google.maps.InfoWindow({
          content: `<div class="p-2">
            <h3 class="font-semibold">${hunter.name}</h3>
            <p class="text-sm text-muted-foreground">
              ${isCurrentUser ? "You" : "Hunter"}
            </p>
          </div>`,
        });

        marker.addListener("click", () => {
          infoWindow.open(map, marker);
        });

        markersRef.current.set(hunter.id, marker);

        const safetyCircle = new google.maps.Circle({
          strokeColor: isCurrentUser ? "#3b82f6" : "#ef4444",
          strokeOpacity: 0.3,
          strokeWeight: 1,
          fillColor: isCurrentUser ? "#3b82f6" : "#ef4444",
          fillOpacity: 0.1,
          map,
          center: { lat: hunter.lat, lng: hunter.lng },
          radius: SAFETY_ZONE_RADIUS,
        });

        safetyZonesRef.current.set(hunter.id, safetyCircle);
      } else {
        marker.setPosition({ lat: hunter.lat, lng: hunter.lng });
        
        const safetyCircle = safetyZonesRef.current.get(hunter.id);
        if (safetyCircle) {
          safetyCircle.setCenter({ lat: hunter.lat, lng: hunter.lng });
        }
      }
    });
  }, [hunters, currentUserId, SAFETY_ZONE_RADIUS]);

  if (error) {
    return (
      <div className="flex items-center justify-center h-full bg-muted">
        <div className="text-center">
          <p className="text-destructive font-medium">{error}</p>
          <p className="text-sm text-muted-foreground mt-2">
            Please check your internet connection
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-background z-10">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Loading map...</p>
          </div>
        </div>
      )}
      <div ref={mapRef} className="w-full h-full" data-testid="map-container" />
    </div>
  );
}
