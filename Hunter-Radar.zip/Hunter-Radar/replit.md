# Hunter Radar - Compass-Based Real-time Hunter Tracking

## Overview
A tactical real-time hunter tracking application with compass-based radar as the primary interface. Features military-inspired camo design with high-visibility safety orange text for outdoor readability. The radar rotates based on device orientation (compass heading) to show hunters' true bearing.

## Project Architecture

### Tech Stack
- **Frontend**: React + TypeScript, Wouter (routing), TanStack Query, Tailwind CSS, Shadcn UI
- **Backend**: Express.js, WebSocket (ws)
- **Device Sensors**: DeviceOrientation API for compass heading
- **Storage**: In-memory storage (MemStorage)
- **Design**: Woodland camo with safety orange (#FF6600) theme
- **Typography**: Rajdhani (headings), Roboto Mono (data), Inter (body)

### Key Features
1. **Compass-Based Radar**: Full-screen radar that rotates based on device orientation/heading
2. **Real-time Position Tracking**: WebSocket-based live hunter location updates
3. **Distance Rings**: Visual distance indicators at 100m, 250m, and 500m
4. **Cardinal Directions**: N, E, S, W markers adjust to compass heading (North highlighted in orange)
5. **Hunter List**: Sidebar showing active hunters sorted by distance
6. **Check-in/Check-out System**: Session tracking with live duration display
7. **Safety Alerts**: Proximity warnings when hunters within 100m
8. **Offline Functionality**: localStorage caching with automatic sync
9. **Camo Theme**: Woodland camouflage backgrounds with safety orange text
10. **Distance Categories**: Color-coded dots (0-100m red, 100-250m amber, 250m+ green)

### Project Structure
```
client/
├── src/
│   ├── components/
│   │   ├── RadarDisplay.tsx - Compass-based radar (PRIMARY VIEW)
│   │   ├── HunterList.tsx - Distance-sorted hunter list sidebar
│   │   ├── ControlBar.tsx - Top bar with session duration and check-out
│   │   └── AlertBanner.tsx - Proximity alert notifications
│   ├── hooks/
│   │   ├── useDeviceOrientation.ts - Compass heading from device sensors
│   │   ├── useWebSocket.ts - WebSocket with offline queue
│   │   └── useGeolocation.ts - GPS position tracking
│   ├── lib/
│   │   ├── maps.ts - Distance/bearing calculations, geofencing
│   │   └── offline.ts - localStorage caching and sync
│   └── pages/
│       └── home.tsx - Main app with full-screen radar
server/
├── routes.ts - API routes and WebSocket server
└── storage.ts - In-memory hunter/boundary storage
shared/
└── schema.ts - TypeScript types and Zod schemas
```

## Environment Variables
- `GOOGLE_MAPS_API_KEY`: Google Maps JavaScript API key (required)
- `SESSION_SECRET`: Express session secret
- `VITE_GOOGLE_MAPS_API_KEY`: Client-side Maps API key (auto-set from GOOGLE_MAPS_API_KEY)

## Data Model

### Hunter
- `id`: Unique identifier
- `name`: Hunter's display name
- `latitude/longitude`: Current position
- `heading`: Direction (optional)
- `lastUpdate`: Timestamp of last position update
- `checkInTime`: Session start timestamp

### Boundary
- `id`: Unique identifier
- `name`: Boundary name
- `coordinates`: Array of lat/lng polygon points

## WebSocket Messages
- `position_update`: Broadcast hunter position changes
- `hunter_joined`: New hunter enters the area
- `hunter_left`: Hunter leaves the area
- `boundary_update`: Boundary changes

## Distance Calculations
Uses Haversine formula for accurate great-circle distances between GPS coordinates. Bearing calculated using forward azimuth formula. Point-to-segment distance for geofencing proximity detection.

## GIS Integration
- **BLM (Bureau of Land Management)**: https://gbp-blm-egis.hub.arcgis.com/
- **USFS (US Forest Service)**: https://data-usfs.hub.arcgis.com/
- Both use ArcGIS REST services returning GeoJSON format
- No authentication required for public land boundary data
- 50-mile radius search from current position

## Offline Functionality
- **Position Queue**: All position updates queued in localStorage when offline
- **Data Caching**: Hunters and boundaries cached for offline viewing
- **Auto-sync**: Queued messages sent automatically when connection restored
- **State Hydration**: Cached data loaded on application startup

## Safety Features
- **Safety Zones**: 100m radius circles around each hunter (blue for self, red for others)
- **Proximity Alerts**: Warnings when hunters within 100m of each other
- **Geofencing**: Alerts when within 200m of any boundary perimeter
- **Distance Categories**: Visual color coding for quick distance assessment

## User Preferences
None yet - future features may include:
- Preferred distance units (meters/feet)
- Custom alert thresholds
- Map style preferences
- Safety zone radius configuration

## Design System
- **Colors**: Woodland camo backgrounds (greens, browns, tans) with safety orange (#FF6600) for all text
- **Fonts**: Rajdhani (tactical headings), Roboto Mono (precise data), Inter (body text)
- **Theme**: Military/hunting aesthetic optimized for outdoor visibility
- **Contrast**: High-contrast orange-on-camo for glove-friendly operation

## Property Boundaries Note
For property line integration, third-party services are required since:
- **onX Hunt** and **HuntStand** don't offer public APIs
- **Google Maps** doesn't include parcel boundaries
- **Options**: Regrid API, county GIS data, or LightBox parcel data (requires licensing)

## Recent Changes (Nov 1, 2025)
- **MAJOR REDESIGN**: Transformed to compass-based radar as primary interface
- Implemented DeviceOrientation API for heading-based compass rotation
- Updated design to woodland camo with safety orange (#FF6600) theme
- Removed map view - radar is now full-screen primary display
- Enhanced radar to show true bearing based on device compass
- North direction highlighted in orange, rotates with device orientation
- Added Rajdhani font for tactical military aesthetic
- Optimized layout for outdoor hunting conditions
