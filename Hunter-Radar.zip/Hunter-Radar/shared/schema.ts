import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const hunters = pgTable("hunters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
  heading: decimal("heading", { precision: 5, scale: 2 }),
  lastUpdate: timestamp("last_update").notNull().defaultNow(),
});

export const boundaries = pgTable("boundaries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  coordinates: text("coordinates").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertHunterSchema = createInsertSchema(hunters).omit({
  id: true,
  lastUpdate: true,
});

export const insertBoundarySchema = createInsertSchema(boundaries).omit({
  id: true,
  createdAt: true,
});

export type InsertHunter = z.infer<typeof insertHunterSchema>;
export type Hunter = typeof hunters.$inferSelect;
export type InsertBoundary = z.infer<typeof insertBoundarySchema>;
export type Boundary = typeof boundaries.$inferSelect;

export interface Position {
  lat: number;
  lng: number;
}

export interface HunterPosition extends Position {
  id: string;
  name: string;
  heading?: number;
  lastUpdate: Date;
}

export interface DistanceInfo {
  distance: number;
  bearing: number;
  hunterId: string;
}

export interface BoundaryPolygon {
  id: string;
  name: string;
  coordinates: Position[];
}

export interface WSMessage {
  type: 'position_update' | 'hunter_joined' | 'hunter_left' | 'boundary_update';
  data: any;
}
